<?php
use Restserver\Libraries\REST_Controller;
defined('BASEPATH') OR exit('No direct script access allowed');
require APPPATH . 'libraries/REST_Controller.php';
require APPPATH . 'libraries/Format.php';

class Produk extends REST_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('Produk_model', 'produk');
	}

	public function index_get()
	{
		$id = $this->get('id');
		if ($id === null) {
			$produk = $this->produk->getProduk();
		}else {
			$produk = $this->produk->getProduk($id);
		}

		// var_dump($produk);
		if ($produk) {
			//jika ada isinya
			$this->set_response([
				'message' => 'success',
                'error' => 'false',
				'code' => 200,
                'url' => 'uploads/thumbs/',				
                'produk' => $produk
            ], REST_Controller::HTTP_OK); // NOT_FOUND (404) being the HTTP response code
		}else {
			$this->set_response([
				'message' => 'failed',
                'error' => 'true',
                'code' => 404,
            ], REST_Controller::HTTP_NOT_FOUND); // NOT_FOUND (404) being the HTTP response code
		}
	}	
}

?>
